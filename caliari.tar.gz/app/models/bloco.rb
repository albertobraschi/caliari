class Bloco < ActiveRecord::Base
  attr_accessible :titulo, :identificador, :conteudo
end
