module FotosHelper
end
